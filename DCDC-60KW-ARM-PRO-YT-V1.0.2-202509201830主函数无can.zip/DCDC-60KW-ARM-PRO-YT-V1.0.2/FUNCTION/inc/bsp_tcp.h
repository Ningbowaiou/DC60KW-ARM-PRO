#ifndef __APPLICATIONTCP_H
#define __APPLICATIONTCP_H

#include "stdlib.h"
#include <stdbool.h>
#include "modbus_slave.h"
#include "net_config.h"

#define IP1              192
#define IP2              168
#define IP3              1
#define IP4              221

extern LOCALM  nlocalm[3] ;
extern LOCALM  nlocalm[3] ;
extern __IO uint8_t  g_ucEthLinkStatus;
extern uint8_t but_ex;
extern uint8_t tcp_status;
extern uint16_t Switch_Counter;
void TCPnetTest(void);
extern uint16_t TcpCom;
extern uint16_t TCPnet;
uint8_t TCP_StatusCheck(void);
extern uint16_t ** ppucFrame1;
extern uint8_t aucTCPBufData;
extern uint8_t aucTCPFunData;
extern uint8_t aucTCPBufDataCount;
extern uint16_t ppucFrame;
extern uint16_t RegDataLast[100];
extern uint8_t data_temp_this_time;
void vTaskTCPnet(void);
#endif


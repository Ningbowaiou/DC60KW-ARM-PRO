#ifndef _BSP_PUBLIC_H
#define _BSP_PUBLIC_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "bsp_gpio.h"
#include "bsp_timer.h"
#include <stdio.h>
#include <math.h>
#include "taskmanage.h"
#include "smarttimer.h"
#include "modbus_slave.h"
#include "stm32f4xx_pwr.h"
#include "mb.h"
#include "mbtcp.h"
#include "mbporttcp.h"
#include "port.h"
#define   Sign  1
#define   Unsign 0
#ifndef TRUE
    #define TRUE  1
#endif

#ifndef FALSE
    #define FALSE 0
#endif

#define DISABLE_INT()    //taskENTER_CRITICAL()
#define ENABLE_INT()    // taskEXIT_CRITICAL()
#define BSP_Printf		   printf

#define RTC_CLOCK_SOURCE_LSE  
//IO�ڲ����궨��
#define BITBAND(addr, bitnum) ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2))
#define MEM_ADDR(addr)  *((volatile unsigned long  *)(addr))
#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum))
//IO�ڵ�ַӳ��
#define GPIOA_ODR_Addr    (GPIOA_BASE+20) //0x40020014
#define GPIOB_ODR_Addr    (GPIOB_BASE+20) //0x40020414 
#define GPIOC_ODR_Addr    (GPIOC_BASE+20) //0x40020814 
#define GPIOD_ODR_Addr    (GPIOD_BASE+20) //0x40020C14 

#define GPIOA_IDR_Addr    (GPIOA_BASE+16) //0x40020010 
#define GPIOB_IDR_Addr    (GPIOB_BASE+16) //0x40020410 
#define GPIOC_IDR_Addr    (GPIOC_BASE+16) //0x40020810 
#define GPIOD_IDR_Addr    (GPIOD_BASE+16) //0x40020C10 

#define PAout(n)   BIT_ADDR(GPIOA_ODR_Addr,n)  
#define PAin(n)    BIT_ADDR(GPIOA_IDR_Addr,n)  

#define PBout(n)   BIT_ADDR(GPIOB_ODR_Addr,n)  
#define PBin(n)    BIT_ADDR(GPIOB_IDR_Addr,n)  

#define PCout(n)   BIT_ADDR(GPIOC_ODR_Addr,n)  
#define PCin(n)    BIT_ADDR(GPIOC_IDR_Addr,n)  

#define PDout(n)   BIT_ADDR(GPIOD_ODR_Addr,n)  
#define PDin(n)    BIT_ADDR(GPIOD_IDR_Addr,n)  

#define US_delay_TIM	TIM7

#define  REV_RATED_PW 	     usRegHoldingBuf[501]//�����
#define  REV_SYS_STATE  	   usRegHoldingBuf[502]//ϵͳ״̬
#define  REV_RUN_MODE  	     usRegHoldingBuf[503]//RUN MODE
#define  REV_BAT_PW     	   usRegHoldingBuf[504]//��ع���
#define  REV_BAT_CUR  	     usRegHoldingBuf[505]//��ص���
#define  REV_BAT_VOL  	     usRegHoldingBuf[506]//��ص�ѹ
#define  REV_HIG_VOL_VAL  	 usRegHoldingBuf[507]//��ѹ���ѹ����
#define  REV_TEMP_VAL   	   usRegHoldingBuf[508]//ģ���¶�
#define  REV_LOW_VOL_DIV   	 usRegHoldingBuf[509]//��ѹ���豸��������
#define  REV_FAULT_CODE      usRegHoldingBuf[510]//������

extern uint16_t TempVal;
extern uint16_t ValueData[6];
extern uint8_t FunSpeedValue;
extern uint8_t FlagVsModel;
extern uint16_t HandlePub;
extern uint8_t Birdmode;
uint8_t USART_Scanf(uint32_t value);
void ADC_Config(void);
void adc_init(void);                   
void adc_channel_set(ADC_TypeDef *adcx, uint8_t ch, uint8_t stime); 
uint32_t adc_get_result(uint8_t ch);
uint32_t adc_get_result_average(uint8_t ch, uint8_t times); 
void  adc_dma_init(uint32_t mar);      
void adc_dma_enable( uint16_t ndtr);  
void adc_nch_dma_init(uint32_t mar);  
void ADCMchiConfig(void);
void temp_data(void);
float Get_Kelvin_Temperature(float Rntc);
float Get_Temp(uint16_t NTC_Res);
void SysTick_ISR(void);
void vSystemHardwareDriverInit(void);
void bsp_Idle(void);
void delay_init(void);
void delay_us(u32 nus);
void delay_ms(u16 repeat);
void USART2_configuration(void);
void vTaskPubPro(void *pvParameters);
void bsp_StartTimer(uint8_t _id, uint32_t _period);
void bsp_StartAutoTimer(uint8_t _id, uint32_t _period);
void dma_usart_tx_config(DMA_Stream_TypeDef *dma_streamx, uint8_t ch, uint32_t par, uint32_t mar);
void dma_basic_config(DMA_Stream_TypeDef *dma_streamx,uint32_t ch, uint32_t par, uint32_t m0ar, uint32_t m1ar);
void dma_enable(DMA_Stream_TypeDef *dma_streamx, uint16_t ndtr);
void adc_nch_dma_init(uint32_t mar);
void CanTxMsgWrData(uint8_t a, uint8_t b, uint8_t c, uint8_t d, uint8_t e);
void vTaskMsgReWrPro(void *pvParameters);
void vTaskMsgRePro(void *pvParameters);
void vTaskMsgCanTxHoPro(void *pvParameters);
void vTaskMsgCanTxInPro(void *pvParameters);
#endif

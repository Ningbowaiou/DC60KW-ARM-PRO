/*********************************************************************
Copyright 2024,   RISEN SYL
File Name: 	      GPIO.c
Description:  	  This file shows
Version:  	      V1_0
Author:  	        WANG YAN ZHAO
Date:  	          2024-06-27
*********************************************************************/
#ifndef __BSP_GPIO_H
#define __BSP_GPIO_H

#include "stm32f4xx.h"

#define GPIO_PORT_ETH        (GPIOB)
#define GPIO_PIN_ETH 	       (GPIO_Pin_15)

#define RCC_ALL_ETH 	       (RCC_AHB1Periph_GPIOB)
#define RCC_ALL_LED 	       (RCC_AHB1Periph_GPIOD)
#define RCC_MODULE_PORT 	   (RCC_AHB1Periph_GPIOE)
#define RCC_VS_CK_PORT1 	   (RCC_AHB1Periph_GPIOE)
#define RCC_VS_CK_PORT2 	   (RCC_AHB1Periph_GPIOC)

#define MODULE_PORT          (GPIOE)
#define MODULE_PW_PIN	       (GPIO_Pin_0)
#define MODULE_EMS_PIN       (GPIO_Pin_1)
#define MODULE_RUN_PIN	     (GPIO_Pin_2)
#define MODULE_FAULT_PIN     (GPIO_Pin_3)

#define MODULE_RUN_ON	       (MODULE_PORT->BSRRL = MODULE_RUN_PIN)
#define MODULE_RUN_OFF	     (MODULE_PORT->BSRRH = MODULE_RUN_PIN)

#define MODULE_FAULT_ON	     (MODULE_PORT->BSRRL = MODULE_FAULT_PIN)
#define MODULE_FAULT_OFF	   (MODULE_PORT->BSRRH = MODULE_FAULT_PIN)

#define MODULE_PW_ON	       (MODULE_PORT->BSRRL = MODULE_PW_PIN)
#define MODULE_PW_OFF	       (MODULE_PORT->BSRRH = MODULE_PW_PIN)

#define MODULE_EMS_ON	       (MODULE_PORT->BSRRL = MODULE_EMS_PIN)
#define MODULE_EMS_OFF	     (MODULE_PORT->BSRRH = MODULE_EMS_PIN)

#define MODULE_LED_PORT      (GPIOD)

#define MODULE_LED1_PIN	     (GPIO_Pin_2)
#define MODULE_LED2_PIN      (GPIO_Pin_3)
#define MODULE_LED3_PIN      (GPIO_Pin_4)

#define MODULE_LED1_ON	     (MODULE_LED_PORT->BSRRH = MODULE_LED1_PIN)
#define MODULE_LED1_OFF	     (MODULE_LED_PORT->BSRRL = MODULE_LED1_PIN)

#define MODULE_LED2_ON	     (MODULE_LED_PORT->BSRRH = MODULE_LED2_PIN)
#define MODULE_LED2_OFF	     (MODULE_LED_PORT->BSRRL = MODULE_LED2_PIN)

#define MODULE_LED3_ON	     (MODULE_LED_PORT->BSRRH = MODULE_LED3_PIN)
#define MODULE_LED3_OFF	     (MODULE_LED_PORT->BSRRL = MODULE_LED3_PIN)

#define MODULE_SW1	         (GPIO_Pin_11)
#define MODULE_SW2           (GPIO_Pin_12)
#define MODULE_SW3           (GPIO_Pin_13)

//#define MODULE_SW1_CK        (GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_11))
//#define MODULE_SW2_CK 			 (GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_12))
//#define MODULE_SW3_CK 			 (GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_13))
//#define MACHINE_PORT          (GPIOD)

//#define MACHINE_RUN_PIN      (GPIO_Pin_9)
//#define MACHINE_ERR_PIN      (GPIO_Pin_10)

//#define MACHINE_RUN	         (MACHINE_PORT->BSRRH = MACHINE_RUN_PIN)
//#define MACHINE_STOP	       (MACHINE_PORT->BSRRL = MACHINE_RUN_PIN)
//#define MACHINE_ERR_EN	     (MACHINE_PORT->BSRRH = MACHINE_ERR_PIN)
//#define MACHINE_ERR_DI	     (MACHINE_PORT->BSRRL = MACHINE_ERR_PIN)

#define FUN_RUN_PORT           (GPIOD)
#define FUN1_OUT_PIN           (GPIO_Pin_12)
#define FUN2_OUT_PIN           (GPIO_Pin_13)
#define FUN3_OUT_PIN           (GPIO_Pin_14)
#define FUN4_OUT_PIN           (GPIO_Pin_15)

#define IO_OUT_PORT            (GPIOE)
#define IO_OUT_PIN_1           (GPIO_Pin_14)
#define IO_OUT_PIN_2           (GPIO_Pin_15)

#define IO_IN_PORT             (GPIOE)
#define IO_IN_PIN_1            (GPIO_Pin_13)
#define IO_IN_PIN_2            (GPIO_Pin_12)
#define IO_IN_PIN_3            (GPIO_Pin_11)

#define VS_CK_PORT1            (GPIOE)
#define VS_CK_PORT2            (GPIOC)
#define VS_CK_PIN_1            (GPIO_Pin_4)
#define VS_CK_PIN_2            (GPIO_Pin_5)
#define VS_CK_PIN_3            (GPIO_Pin_6)
#define VS_CK_PIN_4            (GPIO_Pin_13)

#define IO_OUT_1_ON	           (IO_OUT_PORT->BSRRL = IO_OUT_PIN_1)
#define IO_OUT_1_OFF	         (IO_OUT_PORT->BSRRH = IO_OUT_PIN_1)

#define IO_OUT_2_ON	           (IO_OUT_PORT->BSRRL = IO_OUT_PIN_2)
#define IO_OUT_2_OFF	         (IO_OUT_PORT->BSRRH = IO_OUT_PIN_2)
#define IO_OUT_2_TOG	         (GPIO_ToggleBits(GPIOE, GPIO_Pin_2))

#define IO1_IN_READ         	 (GPIO_ReadInputDataBit(IO_IN_PORT, IO_IN_PIN_1))
#define IO2_IN_READ 			   	 (GPIO_ReadInputDataBit(IO_IN_PORT, IO_IN_PIN_2))
#define IO3_IN_READ 			   	 (GPIO_ReadInputDataBit(IO_IN_PORT, IO_IN_PIN_3))


#define VS_CK_PIN1         		 (GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_4))
#define VS_CK_PIN2 			   		 (GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_5))
#define VS_CK_PIN3 			   		 (GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_6))
#define VS_CK_PIN4 			   		 (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13))

#define ADC_CLK 											     RCC_APB2Periph_ADC1
#define ADC_CHANNEL											   ADC_Channel_8

#define ADC_PIN  											     GPIO_Pin_0
#define ADC_GPIO_PORT										   GPIOB
#define ADC_GPIO_CLK									     RCC_AHB1Periph_GPIOB

#define ADC_ADCX_CHY_GPIO_PORT              GPIOA
#define ADC_ADCX_CHY_GPIO_PIN               SYS_GPIO_PIN5 
#define ADC_ADCX_CHY_GPIO_CLK_ENABLE()      do{ RCC->AHB1ENR |= 1 << 0; }while(0)   

#define FUN_CK_PORT                        (GPIOA)
#define FUN1_CK_PIN                        (GPIO_Pin_3)
#define FUN2_CK_PIN                        (GPIO_Pin_4)
#define FUN3_CK_PIN                        (GPIO_Pin_5)
#define FUN4_CK_PIN                        (GPIO_Pin_6)
#define FUN_GPIO_CLK									     (RCC_AHB1Periph_GPIOA)

#define ADC_ADCX                            ADC1 
#define ADC_ADCX_CHY                        5                                      
#define ADC_ADCX_CHY_CLK_ENABLE()           do{ RCC->APB2ENR |= 1 << 8; }while(0)  

#define ADC_ADCX_DMASx                      DMA2_Stream4
#define ADC_ADCX_DMASx_Channel              0                                     
#define ADC_ADCX_DMASx_IRQn                 DMA2_Stream4_IRQn
#define ADC_ADCX_DMASx_IRQHandler           DMA2_Stream4_IRQHandler

#define ADC_ADCX_DMASx_IS_TC()              ( DMA2->HISR & (1 << 5) )   
                                                                        
                                                                        
#define ADC_ADCX_DMASx_CLR_TC()             do{ DMA2->HIFCR |= 1 << 5; }while(0)   
#define ADC_DMA_BUF_SIZE                    50 * 6    

#define ADC_PIN1  												  GPIO_Pin_0
#define ADC_GPIO_PORT1										  GPIOB
#define ADC_GPIO_CLK1										    RCC_AHB1Periph_GPIOB
 
#define ADC_PIN2  												  GPIO_Pin_1
#define ADC_GPIO_PORT2										  GPIOB
#define ADC_GPIO_CLK2									      RCC_AHB1Periph_GPIOB
 
#define ADC_CLK 											  	  RCC_APB2Periph_ADC1
#define ADC_CHANNEL1											  ADC_Channel_8
#define ADC_CHANNEL2											  ADC_Channel_9
#define ADC_CHANNEL3											  ADC_Channel_3
#define ADC_CHANNEL4											  ADC_Channel_4
#define ADC_CHANNEL5											  ADC_Channel_5
#define ADC_CHANNEL6											  ADC_Channel_6
#define ADC1_DR_BASE											  ((uint32_t)ADC1+0x4c)
 
#define ADC_DMA_CLK 											  RCC_AHB1Periph_DMA2
#define ADC_DMA_CHANNEL  									  DMA_Channel_0
#define ADC_DMA_STREAM   									  DMA2_Stream0


void BspIoConfig(void);

#endif

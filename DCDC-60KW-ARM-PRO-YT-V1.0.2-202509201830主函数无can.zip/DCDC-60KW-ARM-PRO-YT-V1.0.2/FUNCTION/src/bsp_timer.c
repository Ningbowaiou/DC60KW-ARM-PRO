#include "bsp_pub.h"
#include "bsp_timer.h"
#include "bsp_tcp.h"
static volatile uint32_t s_uiDelayCount = 0;
static volatile uint8_t s_ucTimeOutFlag = 0;

static SOFT_TMR s_tTmr[TMR_COUNT];
volatile uint8_t RunPer10ms = 0;

__IO int32_t g_iRunTime = 0;
volatile uint8_t count = 0;
static void bsp_SoftTimerDec(SOFT_TMR *_tmr);

void bsp_RunPer10ms(void)
{
  RunPer10ms--;
}



void bsp_Idle(void)
{

}

void bsp_InitTimer(void)
{
	
	uint8_t i;

	for (i = 0; i < TMR_COUNT; i++)
	{
		s_tTmr[i].Count = 0;
		s_tTmr[i].PreLoad = 0;
		s_tTmr[i].Flag = 0;
		s_tTmr[i].Mode = TMR_ONCE_MODE;	
	}
	SysTick_Config(SystemCoreClock / 1000);
   NVIC_EnableIRQ(SysTick_IRQn);
	
}


void SysTick_Init_Manual(uint32_t ms) 
	{
    uint32_t freq = SystemCoreClock; 
    uint32_t ticks = freq / 1000 * ms;

    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;

    if (ticks > 0xFFFFFF) ticks = 0xFFFFFF; 
    SysTick->LOAD = ticks - 1;  

    SysTick->VAL = 0;

    SysTick->CTRL |= SysTick_CTRL_CLKSOURCE_Msk | SysTick_CTRL_TICKINT_Msk;

    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;

    __enable_irq();
}

extern void bsp_RunPer1ms(void);
extern void bsp_RunPer10ms(void);
void SysTick_ISR(void)
{
	static uint8_t s_count = 0;
	uint8_t i;

	if (s_uiDelayCount > 0)
	{
		if (--s_uiDelayCount == 0)
		{
			s_ucTimeOutFlag = 1;
		}
	}

	for (i = 0; i < TMR_COUNT; i++)
	{
		bsp_SoftTimerDec(&s_tTmr[i]);
	}

	g_iRunTime++;
	if (g_iRunTime == 0x7FFFFFFF)	
	{
		g_iRunTime = 0;
	}
	count++;
	if(g_ucEthLinkStatus ^ but_ex)
	{
			but_ex = g_ucEthLinkStatus;

			if(g_ucEthLinkStatus == 1)
			{
					init_ethernet();
			}
	}
	main_TcpNet();
	tcp_status = TCP_StatusCheck();
	Switch_Counter = read_PHY(0x12);
	if(my_tcp.send_flag == 1)
	{
			my_tcp.send_flag = 0;
			my_tcp_send(my_tcp.send_buffer, my_tcp.send_counter);
			my_tcp.send_ok = 1;
	}	
	
//	bsp_RunPer1ms();	

	if (++s_count >= 10)
	{
		s_count = 0;

		bsp_RunPer10ms();
	}
}


static void bsp_SoftTimerDec(SOFT_TMR *_tmr)
{
	if (_tmr->Count > 0)
	{
		if (--_tmr->Count == 0)
		{
			_tmr->Flag = 1;

			if(_tmr->Mode == TMR_AUTO_MODE)
			{
				_tmr->Count = _tmr->PreLoad;
			}
		}
	}
}


void bsp_DelayMS(uint32_t n)
{
	if (n == 0)
	{
		return;
	}
	else if (n == 1)
	{
		n = 2;
	}

	DISABLE_INT();  	
	s_uiDelayCount = n;
	s_ucTimeOutFlag = 0;

	ENABLE_INT();  			

	while (1)
	{
		bsp_Idle();				
		if (s_ucTimeOutFlag == 1)
		{
			break;
		}
	}
}

void bsp_DelayUS(uint32_t n)
{
    uint32_t ticks;
    uint32_t told;
    uint32_t tnow;
    uint32_t tcnt = 0;
    uint32_t reload;
       
	  reload = SysTick->LOAD;                
    ticks = n * (SystemCoreClock / 1000000);	

    tcnt = 0;
    told = SysTick->VAL;           
    while (1)
    {
        tnow = SysTick->VAL;    
        if (tnow != told)
        {      
            if (tnow < told)
            {
                tcnt += told - tnow;    
            }
            else
            {
                tcnt += reload - tnow + told;    
            }        
            told = tnow;
            if (tcnt >= ticks)
            {
            	break;
            }
        }  
    }
} 


void bsp_StartTimer(uint8_t _id, uint32_t _period)
{

	DISABLE_INT();  		

	s_tTmr[_id].Count = _period;	
	s_tTmr[_id].PreLoad = _period;		
	s_tTmr[_id].Flag = 0;				
	s_tTmr[_id].Mode = TMR_ONCE_MODE;	

	ENABLE_INT();  		
}

void bsp_StartAutoTimer(uint8_t _id, uint32_t _period)
{

	DISABLE_INT();  

	s_tTmr[_id].Count = _period;		
	s_tTmr[_id].PreLoad = _period;	
	s_tTmr[_id].Flag = 0;				      
	s_tTmr[_id].Mode = TMR_AUTO_MODE;	

	ENABLE_INT();  			
}


void bsp_StopTimer(uint8_t _id)
{
	DISABLE_INT();  
	s_tTmr[_id].Count = 0;			
	s_tTmr[_id].Flag = 0;				
	s_tTmr[_id].Mode = TMR_ONCE_MODE;	

	ENABLE_INT();  	
}


uint8_t bsp_CheckTimer(uint8_t _id)
{
	if (s_tTmr[_id].Flag == 1)
	{
		s_tTmr[_id].Flag = 0;
		return 1;
	}
	else
	{
		return 0;
	}
}


int32_t bsp_GetRunTime(void)
{
	int32_t runtime;
	DISABLE_INT();  	
	runtime = g_iRunTime;	
	ENABLE_INT();  	
	return runtime;
}


void SysTick_Handler(void)
{
	SysTick_ISR();
}


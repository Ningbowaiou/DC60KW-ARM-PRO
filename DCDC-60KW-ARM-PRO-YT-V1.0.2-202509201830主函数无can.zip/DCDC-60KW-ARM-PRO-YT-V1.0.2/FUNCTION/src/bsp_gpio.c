#include "bsp_pub.h"
#include "modbus_slave.h"
#include "bsp_gpio.h"

/*******************************************************************************
* Function Name  : BspIoConfig(void)
* Description    : init the led
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void BspIoConfig(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_AHB1PeriphClockCmd(RCC_ALL_ETH|RCC_ALL_LED|RCC_MODULE_PORT|RCC_VS_CK_PORT1|RCC_VS_CK_PORT2, ENABLE);
	
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	
    GPIO_InitStructure.GPIO_Pin = MODULE_RUN_PIN | MODULE_FAULT_PIN | MODULE_PW_PIN | MODULE_EMS_PIN;
    GPIO_Init(MODULE_PORT, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = MODULE_LED1_PIN | MODULE_LED2_PIN | MODULE_LED3_PIN;
    GPIO_Init(MODULE_LED_PORT, &GPIO_InitStructure);
	
    GPIO_InitStructure.GPIO_Pin = IO_OUT_PIN_1 | IO_OUT_PIN_2;
    GPIO_Init(IO_OUT_PORT, &GPIO_InitStructure);
	
    MODULE_LED1_OFF;
    MODULE_LED2_OFF;
    MODULE_LED3_OFF;
    MODULE_RUN_OFF;
		MODULE_FAULT_OFF;
		MODULE_PW_OFF;
		MODULE_EMS_OFF;
		IO_OUT_1_OFF;
		IO_OUT_2_OFF;
	
    GPIO_InitStructure.GPIO_Pin = IO_IN_PIN_1 | IO_IN_PIN_2 | IO_IN_PIN_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(IO_IN_PORT, &GPIO_InitStructure);
		
//    GPIO_InitStructure.GPIO_Pin = FUN1_CK_PIN | FUN2_CK_PIN | FUN3_CK_PIN | FUN4_CK_PIN;  //input
//    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
//    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
//    GPIO_Init(FUN_CK_PORT, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = VS_CK_PIN_1 | VS_CK_PIN_2 | VS_CK_PIN_3;   //input
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
    GPIO_Init(VS_CK_PORT1, &GPIO_InitStructure);
		
    GPIO_InitStructure.GPIO_Pin = VS_CK_PIN_4;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
    GPIO_Init(VS_CK_PORT2, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_PIN_ETH;
    GPIO_Init(GPIO_PORT_ETH, &GPIO_InitStructure);

    GPIO_ResetBits(GPIO_PORT_ETH, GPIO_PIN_ETH);
    Delay(0XFFFF);
    GPIO_SetBits(GPIO_PORT_ETH, GPIO_PIN_ETH);

}

///*******************************************************************************
//* Function Name  : bsp_LedOn(void)
//* Description    : bsp_LedOn
//* Input          : None
//* Output         : None
//* Return         : None
//*******************************************************************************/
//void ModuleNum(uint8_t _no)
//{

//}


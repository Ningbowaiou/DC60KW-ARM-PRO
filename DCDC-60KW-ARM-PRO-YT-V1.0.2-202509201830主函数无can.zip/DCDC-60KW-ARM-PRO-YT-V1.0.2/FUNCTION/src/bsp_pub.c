#include "bsp_pub.h"
#include "bsp_network.h"
#include "mbtcp.h"
#include "./bsp_debug_usart.h"

volatile uint32_t ulHighFrequencyTimerTicks = 0U;
uint8_t FunSpeedValue = 0;
uint8_t FlagVsModel = 0;

uint32_t bsp_GetRCCofTIM(TIM_TypeDef* TIMx)
{
    uint32_t rcc = 0;

    /*
    	APB1 ��ʱ���� TIM2, TIM3 ,TIM4, TIM5, TIM6, TIM7, TIM12, TIM13, TIM14
    	APB2 ��ʱ���� TIM1, TIM8 ,TIM9, TIM10, TIM11
    */
    if (TIMx == TIM1)
    {
        rcc = RCC_APB2Periph_TIM1;
    }
    else if (TIMx == TIM8)
    {
        rcc = RCC_APB2Periph_TIM8;
    }
    else if (TIMx == TIM9)
    {
        rcc = RCC_APB2Periph_TIM9;
    }
    else if (TIMx == TIM10)
    {
        rcc = RCC_APB2Periph_TIM10;
    }
    else if (TIMx == TIM11)
    {
        rcc = RCC_APB2Periph_TIM11;
    }
    /* ������ APB1ʱ�� */
    else if (TIMx == TIM2)
    {
        rcc = RCC_APB1Periph_TIM2;
    }
    else if (TIMx == TIM3)
    {
        rcc = RCC_APB1Periph_TIM3;
    }
    else if (TIMx == TIM4)
    {
        rcc = RCC_APB1Periph_TIM4;
    }
    else if (TIMx == TIM5)
    {
        rcc = RCC_APB1Periph_TIM5;
    }
    else if (TIMx == TIM6)
    {
        rcc = RCC_APB1Periph_TIM6;
    }
    else if (TIMx == TIM7)
    {
        rcc = RCC_APB1Periph_TIM7;
    }
    else if (TIMx == TIM12)
    {
        rcc = RCC_APB1Periph_TIM12;
    }
    else if (TIMx == TIM13)
    {
        rcc = RCC_APB1Periph_TIM13;
    }
    else if (TIMx == TIM14)
    {
        rcc = RCC_APB1Periph_TIM14;
    }

    return rcc;
}

/*
*********************************************************************************************************
*	�� �� ��: bsp_SetTIMforInt
*	����˵��: ����TIM��NVIC�����ڼ򵥵Ķ�ʱ�ж�. ������ʱ�жϡ� �жϷ��������Ӧ�ó���ʵ�֡�
*	��    ��: TIMx : ��ʱ��
*			  _ulFreq : ��ʱƵ�� ��Hz���� 0 ��ʾ�رա�
*			  _PreemptionPriority : �ж����ȼ�����
*			  _SubPriority : �����ȼ�
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void bsp_SetTIMforInt(TIM_TypeDef* TIMx, uint32_t _ulFreq, uint8_t _PreemptionPriority, uint8_t _SubPriority)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    uint16_t usPeriod;
    uint16_t usPrescaler;
    uint32_t uiTIMxCLK;

    /* ʹ��TIMʱ�� */
    if ((TIMx == TIM1) || (TIMx == TIM8) || (TIMx == TIM9) || (TIMx == TIM10) || (TIMx == TIM11))
    {
        RCC_APB2PeriphClockCmd(bsp_GetRCCofTIM(TIMx), ENABLE);
    }
    else
    {
        RCC_APB1PeriphClockCmd(bsp_GetRCCofTIM(TIMx), ENABLE);
    }

    if (_ulFreq == 0)
    {
        TIM_Cmd(TIMx, DISABLE);		/* �رն�ʱ��� */
        return;
    }

    /*-----------------------------------------------------------------------
    	system_stm32f4xx.c �ļ��� void SetSysClock(void) ������ʱ�ӵ��������£�

    	HCLK = SYSCLK / 1     (AHB1Periph)
    	PCLK2 = HCLK / 2      (APB2Periph)
    	PCLK1 = HCLK / 4      (APB1Periph)

    	��ΪAPB1 prescaler != 1, ���� APB1�ϵ�TIMxCLK = PCLK1 x 2 = SystemCoreClock / 2;
    	��ΪAPB2 prescaler != 1, ���� APB2�ϵ�TIMxCLK = PCLK2 x 2 = SystemCoreClock;

    	APB1 ��ʱ���� TIM2, TIM3 ,TIM4, TIM5, TIM6, TIM7, TIM12, TIM13,TIM14
    	APB2 ��ʱ���� TIM1, TIM8 ,TIM9, TIM10, TIM11

    ----------------------------------------------------------------------- */
    if ((TIMx == TIM1) || (TIMx == TIM8) || (TIMx == TIM9) || (TIMx == TIM10) || (TIMx == TIM11))
    {
        /* APB2 ��ʱ�� */
        uiTIMxCLK = SystemCoreClock;
    }
    else	/* APB1 ��ʱ�� */
    {
        uiTIMxCLK = SystemCoreClock / 2;
    }

    if (_ulFreq <= 10)
    {
        usPrescaler = 42000 - 1;					/* ��Ƶ�� = 1000 */
        usPeriod =  (uiTIMxCLK / 42000) / _ulFreq  - 1;		/* �Զ���װ��ֵ */
    }

    if (_ulFreq <= 100)
    {
        usPrescaler = 10000 - 1;					/* ��Ƶ�� = 1000 */
        usPeriod =  (uiTIMxCLK / 10000) / _ulFreq  - 1;		/* �Զ���װ��ֵ */
    }
    else if (_ulFreq <= 3000)
    {
        usPrescaler = 100 - 1;					/* ��Ƶ�� = 100 */
        usPeriod =  (uiTIMxCLK / 100) / _ulFreq  - 1;		/* �Զ���װ��ֵ */
    }
    else	/* ����4K��Ƶ�ʣ������Ƶ */
    {
        usPrescaler = 0;					/* ��Ƶ�� = 1 */
        usPeriod = uiTIMxCLK / _ulFreq - 1;	/* �Զ���װ��ֵ */
    }

    /* Time base configuration */
    TIM_TimeBaseStructure.TIM_Period = usPeriod;
    TIM_TimeBaseStructure.TIM_Prescaler = usPrescaler;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0x0000;		/* TIM1 �� TIM8 �������� */

    TIM_TimeBaseInit(TIMx, &TIM_TimeBaseStructure);

    TIM_ARRPreloadConfig(TIMx, ENABLE);

    /* TIM Interrupts enable */
    TIM_ITConfig(TIMx, TIM_IT_Update, ENABLE);

    /* TIMx enable counter */
    TIM_Cmd(TIMx, ENABLE);

    /* ����TIM��ʱ�����ж� (Update) */
    {
        NVIC_InitTypeDef NVIC_InitStructure;	/* �жϽṹ���� misc.h �ж��� */
        uint8_t irq = 0;	/* �жϺ�, ������ stm32f4xx.h */

        if ((TIMx == TIM1) || (TIMx == TIM10))
            irq = TIM1_UP_TIM10_IRQn;
        else if (TIMx == TIM2)
            irq = TIM2_IRQn;
        else if (TIMx == TIM3)
            irq = TIM3_IRQn;
        else if (TIMx == TIM4)
            irq = TIM4_IRQn;
        else if (TIMx == TIM5)
            irq = TIM5_IRQn;
        else if (TIMx == TIM6)
            irq = TIM6_DAC_IRQn;
        else if (TIMx == TIM7)
            irq = TIM7_IRQn;
        else if (TIMx == TIM7)
            irq = TIM7_IRQn;
        else if (TIMx == TIM7)
            irq = TIM7_IRQn;
        else if ((TIMx == TIM8) || (TIMx == TIM13))
            irq = TIM8_UP_TIM13_IRQn;
        else if (TIMx == TIM9)
            irq = TIM1_BRK_TIM9_IRQn;
        else if (TIMx == TIM11)
            irq = TIM1_TRG_COM_TIM11_IRQn;
        else if (TIMx == TIM12)
            irq = TIM8_BRK_TIM12_IRQn;
        else if (TIMx == TIM12)
            irq = TIM8_TRG_COM_TIM14_IRQn;

        NVIC_InitStructure.NVIC_IRQChannel = irq;
        NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = _PreemptionPriority;
        NVIC_InitStructure.NVIC_IRQChannelSubPriority = _SubPriority;
        NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
        NVIC_Init(&NVIC_InitStructure);
    }
}


/*******************************************************************************
* Function Name  : delay_init
* Description    : delay_init
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void delay_init(void)
{    
    __set_PRIMASK(1);
    bsp_SetTIMforInt(US_delay_TIM, 1400000, 10, 1);
    TIM_Cmd(US_delay_TIM, DISABLE);
    TIM_ITConfig(US_delay_TIM, TIM_IT_Update, DISABLE);	
	  __set_PRIMASK(0);
}


/*******************************************************************************
* Function Name  : delay_us(u32 nus)
* Description    : delay_us
* Input          : u32 nus
* Output         : None
* Return         : None
*******************************************************************************/
void delay_us(u32 nus)
{
    u32 cnt;
    cnt = nus;
    TIM_Cmd(US_delay_TIM, ENABLE);

    while(cnt--)
    {
        while(TIM_GetFlagStatus(US_delay_TIM, TIM_FLAG_Update) == RESET);

        TIM_ClearFlag(US_delay_TIM, TIM_FLAG_Update);
    }

    TIM_Cmd(US_delay_TIM, DISABLE);
}
/*******************************************************************************
* Function Name  : delay_ms(u16 nms)
* Description    : delay_us
* Input          : u32 nus
* Output         : None
* Return         : None
*******************************************************************************/
void delay_ms(u16 repeat)
{	 	 
	//u16 repeat=nms;						
	while(repeat)
  {
		repeat--;
		delay_us(1500);
	}
} 
/*******************************************************************************
* Function Name  : TIM7_IRQHandler(void)
* Description    : TIM7_IRQHandler
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void TIM7_IRQHandler( void )
{
    if(TIM_GetITStatus(US_delay_TIM, TIM_IT_Update) != RESET)
    {
        TIM_ClearITPendingBit(US_delay_TIM, TIM_IT_Update);
    }
}

/******************************************************************************
* Function Name  : USART_Scanf(void) 
* Description    : rev the uart data
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
uint8_t USART_Scanf(uint32_t value)
{
	uint32_t index = 0;
	uint32_t tmp[2] = {0, 0};

	while (index < 2)
	{
		// RXNE = 1 
		while (USART_GetFlagStatus(USART1, USART_FLAG_RXNE) == RESET)
		{}
		tmp[index++] = (USART_ReceiveData(USART1));
		if ((tmp[index - 1] < 0x30) || (tmp[index - 1] > 0x39))
		{
			index--;
		}
	}
	index = (tmp[1] - 0x30) + ((tmp[0] - 0x30) * 10);
	/* Checks */
	if (index > value)
	{
		return 0xFF;
	}
	
	return index;
}

/*******************************************************************************
* Function Name  : ModuleCheck(void)
* Description    : check the module
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void ModuleCheck(void)
{
		if((VS_CK_PIN1 == SET)&&(VS_CK_PIN2 == RESET)&&(VS_CK_PIN3 == RESET)&&(VS_CK_PIN4 == RESET))   //001
		{			
			//MODULE_LED1_ON;MODULE_LED2_OFF;MODULE_LED3_OFF;	
			;			
		}
		else if((VS_CK_PIN1 == SET)&&(VS_CK_PIN2 == SET)&&(VS_CK_PIN3 == SET)&&(VS_CK_PIN4 == SET))   //1111
		{
			FlagVsModel = 0x0f;
		} 		
		else;
}

uint16_t ucStatus = 0;
/*******************************************************************************
* Function Name  : vSystemHardwareDriverInit(void)
* Description    : init the driver
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void vSystemHardwareDriverInit(void)
{	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);	
	delay_init();  
	//vSetupSysInfoTest();    


	//BspStartAutoTimer(0, 2);
	//BspStartAutoTimer(1, 100);	
	BspIoConfig();  
	ModuleCheck();	
//	at24cxx_init();
//	syl_can_Init();
}



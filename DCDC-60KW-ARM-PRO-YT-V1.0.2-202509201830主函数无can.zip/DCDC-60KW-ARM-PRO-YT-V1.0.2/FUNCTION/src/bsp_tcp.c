#include "bsp_tcp.h"
#include "stm32f4xx.h"
#include "app_tcpnet_lib.h"
#include "port.h"
#include "mbtcp.h"

uint16_t TcpCom = NULL;
uint16_t TCPnet = NULL;

#define PORT_NUM         502
#define LocalPort_NUM    1024
#define socket_num 3

__IO tcp_stu  my_tcp;
uint8_t  tcp_send_buffer[RING_BUFSIZE];
uint8_t *tcp_pbuf;
uint8_t socket_tcp;
uint8_t socket_cnt;
uint8_t mysocket_tcp[socket_num];
uint8_t Rem_IP[4] = {IP1, IP2, IP3, IP4};
uint16_t Switch_Counter;

int32_t i, iCount;
uint8_t tcp_status;
uint8_t res;
const uint16_t usMaxBlockTime = 2;
uint8_t but_ex;

U8 mytcp_callback(U8 soc, U8 evt, U8 *ptr, U16 par, U8 sn)
{
    uint16_t i, j;
    uint8_t *sendbuf;
    uint16_t maxlen;
    if (soc != mysocket_tcp[sn])
    {
        return (0);
    }
    switch (evt)
    {
        case TCP_EVT_CONREQ:
            return (1);
        case TCP_EVT_ABORT:
            my_tcp.link_status = FALSE;
            break;
        case TCP_EVT_CONNECT:
            my_tcp.link_status = TRUE;
            break;
        case TCP_EVT_CLOSE:
            my_tcp.link_status = FALSE;
            break;
        case TCP_EVT_ACK:
            break;
        case TCP_EVT_DATA:
            memcpy(aucTCPBuf, ptr, par);
            usTCPBufLen = par;
            ( void )xMBPortEventPostTcp( EV_FRAME_RECEIVED );		
            break;
    }
    return (0);
}


U16 tcp_callback1 (U8 soc, U8 evt, U8 *ptr, U16 par)
{
    mytcp_callback(soc, evt, ptr, par, 0);
}
U16 tcp_callback2 (U8 soc, U8 evt, U8 *ptr, U16 par)
{
    mytcp_callback(soc, evt, ptr, par, 1);
}
U16 tcp_callback3 (U8 soc, U8 evt, U8 *ptr, U16 par)
{
    mytcp_callback(soc, evt, ptr, par, 2);
}

/*******************************************************************************
* Function Name  : TCP_StatusCheck()
* Description    :
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
uint8_t TCP_StatusCheck(void)
{
    uint8_t res, i;
    for(i = 0; i < socket_num; i++)
    {
        switch (tcp_get_state(mysocket_tcp[i]))
        {
            case TCP_STATE_FREE:
            case TCP_STATE_CLOSED:
            {
                if (mysocket_tcp[i] > 0)
                {
                      delay_ms(20);
											tcp_abort(mysocket_tcp[i]);
											tcp_close(mysocket_tcp[i]);
											res = tcp_listen (mysocket_tcp[i], PORT_NUM);
											delay_ms(20);																	  	
                }
            }
            break;
            case TCP_STATE_LISTEN:
                break;
            case TCP_STATE_CONNECT:
                return (__TRUE);
            default:
                break;
        }
    }
    return (__FALSE);
}

/*******************************************************************************
* Function Name  : my_tcp_send()
* Description    :
* Input          :uint8_t *ptr, uint16_t length
* Output         : None
* Return         : None
*******************************************************************************/
void my_tcp_send(uint8_t *ptr, uint16_t length)
{
    int32_t iCount;
    __IO uint16_t maxlen;
    uint8_t *p, i;
    for(i = 0; i < socket_num; i++)
    {
        if (tcp_check_send (mysocket_tcp[i]) == __TRUE)
        {
            iCount = length;
            do
            {
                main_TcpNet();
                if (tcp_check_send (mysocket_tcp[i]) == __TRUE)
                {
                    maxlen = tcp_max_dsize (mysocket_tcp[i]);
                    iCount -= maxlen;

                    if(iCount < 0)
                    {
                        maxlen = iCount + maxlen;
                    }
                    p = tcp_get_buf(maxlen);
                    memcpy(p, ptr, maxlen);
                    //p=ptr;
                    tcp_send (mysocket_tcp[i], p, maxlen);
                }
                else
                {
                    if(my_tcp.link_status == FALSE)
                    {
                        iCount = 0;
                    }
                }
            }
            while(iCount > 0);
        }
    }
}

   
/*******************************************************************************
* Function Name  : vTaskTCPnet(u8 Bright)
* Description    :
* Input          :
* Output         : None
* Return         : None
*******************************************************************************/
void vTaskTCPnet(void)
{
		uint8_t  i2,i3;
    nlocalm[0].IpAdr[0] = Rem_IP[0];
    nlocalm[0].IpAdr[1] = Rem_IP[1];
    nlocalm[0].IpAdr[2] = Rem_IP[2];
    nlocalm[0].IpAdr[3] = Rem_IP[3];
    delay_ms(200);	
    init_TcpNet ();
    int32_t i, iCount;
    uint8_t res;
    uint8_t but_ex;
    but_ex = g_ucEthLinkStatus;
    mysocket_tcp[0] = tcp_get_socket (TCP_TYPE_SERVER | TCP_TYPE_KEEP_ALIVE, 0, 10, tcp_callback1);
    if(mysocket_tcp[0] != 0){
        res = tcp_listen (mysocket_tcp[0], PORT_NUM);
    } else {
    }
    mysocket_tcp[1] = tcp_get_socket (TCP_TYPE_SERVER | TCP_TYPE_KEEP_ALIVE, 0, 10, tcp_callback2);
    if(mysocket_tcp[1] != 0){
        res = tcp_listen (mysocket_tcp[1], PORT_NUM);
    } else {
    }
    mysocket_tcp[2] = tcp_get_socket (TCP_TYPE_SERVER | TCP_TYPE_KEEP_ALIVE, 0, 10, tcp_callback3);
    if(mysocket_tcp[2] != 0){
        res = tcp_listen (mysocket_tcp[2], PORT_NUM);
    } else {
    } 		    
    eMBTCPInit(MB_TCP_PORT_USE_DEFAULT);	
    eMBTcpEnable();		
}

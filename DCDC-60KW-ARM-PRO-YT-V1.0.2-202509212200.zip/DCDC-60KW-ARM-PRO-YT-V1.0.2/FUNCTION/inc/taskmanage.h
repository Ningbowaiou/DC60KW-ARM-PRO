/*******************************************************************************
* Function Name  : TASKMANAGE
* Description    : TASKMANAGE
* Input          : None
* Output         : None
* Return         : None
* BY             : WANGYANZHAO
* DATE           : 20240702
********************************************************************************/
#ifndef __TASKMANAGE_H
#define __TASKMANAGE_H

#include "bsp_pub.h"
#include "Public.h" 
extern float Measurement[2];

#define RING_BUFSIZE 16384
#define	I7D0	0x00
#define	I5D1	0x01
#define	I4D2	0x02
#define	I3D3	0x03
#define	I2D4	0x04
#define	I1D5	0x05

extern uint8_t *tcp_pbuf;

typedef struct tcp
{
    __IO uint8_t  read_buffer[1024];
    __IO uint8_t  send_buffer[1024];
    __IO uint8_t  send_flag, send_ok;
    __IO uint16_t  send_counter;
    __IO uint8_t link_status;
} tcp_stu;
extern   __IO tcp_stu  my_tcp;

#define Channal_Max_Num 1
#define Filter_Max_Num 16

extern uint16_t xHandleTaskLED;
extern uint16_t xHandleTaskAD717x;
extern uint16_t xHandleTaskDC;
extern uint16_t xHandleTaskACL;
extern uint16_t xHandleTaskACH;

void vTaskCreateFunction (void);
void AppSemaphoreCreate (void);
#endif

#ifndef __BSP_TIMER_H
#define __BSP_TIMER_H

#include "stm32f4xx.h"

#define TMR_COUNT	4		

#define ENABLE_INT()	__set_PRIMASK(0)	
#define DISABLE_INT()	__set_PRIMASK(1)	

//__set_PRIMASK(0)  /*  enable */
//__set_PRIMASK(1)  /* desible*/

#define PWMAMLGT_ARR 90		
#define T0H 30						
#define T1H 60						
#define DATA_SIZE  24 	   


typedef enum
{
    TMR_ONCE_MODE = 0,		/* һ�ι���ģʽ */
    TMR_AUTO_MODE = 1		  /* �Զ���ʱ����ģʽ */
} TMR_MODE_E;

typedef struct
{
    volatile uint8_t Mode;		/* ������ģʽ��1���� */
    volatile uint8_t Flag;		/* ��ʱ�����־  */
    volatile uint32_t Count;	/* ������ */
    volatile uint32_t PreLoad;	/* ������Ԥװֵ */
} SOFT_TMR;


struct publc_bits {
    uint32_t Normal: 1;
    uint32_t CountMs: 6;
    uint32_t FlagUs: 1;
    uint32_t FlagVolBatComp: 2;
    uint32_t StopPmd: 1;
    uint32_t Golden_Start: 1;
    uint32_t DD1_Hardware_Error: 1;
    uint32_t DD1_Port_A_Over_current_protection: 1;
    uint32_t DD1_Port_B_Fast_Over_current_protection: 1;
    uint32_t DD1_Port_B_Slow_Over_current_protection: 1;
    uint32_t reserved: 16; // ???????
};

union publc
{
    uint32_t                all;
    struct publc_bits       bit;
};
extern volatile uint8_t count;
extern volatile uint8_t RunPer10ms;
void SysTick_Init_Manual(uint32_t ms);
void BspInitTimer(void);
void bsp_InitTimer(void);
void bsp_DelayMS(uint32_t n);
void bsp_DelayUS(uint32_t n);
void bsp_StartTimer(uint8_t _id, uint32_t _period);
void bsp_StartAutoTimer(uint8_t _id, uint32_t _period);
void bsp_StopTimer(uint8_t _id);
void BspStartAutoTimer(uint8_t _id, uint32_t _period);
uint8_t bsp_CheckTimer(uint8_t _id);
int32_t bsp_GetRunTime(void);
int32_t bsp_CheckRunTime(int32_t _LastTime);
void bsp_InitHardTimer(void);
void bsp_StartHardTimer(uint8_t _CC, uint32_t _uiTimeOut, void * _pCallBack);
void bsp_RunPer10ms(void);
#endif

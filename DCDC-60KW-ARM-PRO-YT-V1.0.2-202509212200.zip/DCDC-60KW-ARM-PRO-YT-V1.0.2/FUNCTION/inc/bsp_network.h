#ifndef _CAN_NETWORK_H
#define _CAN_NETWORK_H

#include "stm32f4xx_can.h"

#define CAN1_CLK                    RCC_APB1Periph_CAN1
#define CAN1_RX_PIN                 GPIO_Pin_0
#define CAN1_TX_PIN                 GPIO_Pin_1
#define CAN1_GPIO_PORT              GPIOD
#define CAN1_GPIO_TX_CLK            RCC_AHB1Periph_GPIOD
#define CAN1_GPIO_RX_CLK            RCC_AHB1Periph_GPIOD
#define CAN1_AF_PORT                GPIO_AF_CAN1
#define CAN1_RX_SOURCE              GPIO_PinSource0
#define CAN1_TX_SOURCE              GPIO_PinSource1


#define CAN2_CLK                 RCC_APB1Periph_CAN2
#define CAN2_RX_PIN              GPIO_Pin_5
#define CAN2_TX_PIN              GPIO_Pin_6
#define CAN2_GPIO_PORT           GPIOB
#define CAN2_GPIO_CLK            RCC_AHB1Periph_GPIOB
#define CAN2_AF_PORT             GPIO_AF_CAN2
#define CAN2_RX_SOURCE           GPIO_PinSource5
#define CAN2_TX_SOURCE           GPIO_PinSource6

//extern CanRxMsg g_tCanRxMsg;
//extern CanTxMsg g_tCanTxMsg;

void syl_can_Init(void);
void syl_can_Led(void);
#endif


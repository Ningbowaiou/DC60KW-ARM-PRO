#include "bsp_pub.h"
#include "bsp_network.h"
#include "mbtcp.h"
#include "./bsp_debug_usart.h"
#include "taskmanage.h"
#include "bsp_pub.h"
#include "bsp_tcp.h"
#include <Net_Config.h>


volatile uint32_t ulHighFrequencyTimerTicks = 0U;
uint8_t      FunSpeedValue = 0;
uint8_t      FlagVsModel = 0;
uint16_t     ucQueueMsgValue = 0;
uint16_t     ucQueueMsgFunction = 0;
bool         PriorityToken = 0;
extern CanTxMsg g_tCanTxMsg;    
extern CanTxMsg g_tCanRxMsg;  


uint32_t bsp_GetRCCofTIM(TIM_TypeDef* TIMx)
{
    uint32_t rcc = 0;

    /*
    	APB1 ��ʱ���� TIM2, TIM3 ,TIM4, TIM5, TIM6, TIM7, TIM12, TIM13, TIM14
    	APB2 ��ʱ���� TIM1, TIM8 ,TIM9, TIM10, TIM11
    */
    if (TIMx == TIM1)
    {
        rcc = RCC_APB2Periph_TIM1;
    }
    else if (TIMx == TIM8)
    {
        rcc = RCC_APB2Periph_TIM8;
    }
    else if (TIMx == TIM9)
    {
        rcc = RCC_APB2Periph_TIM9;
    }
    else if (TIMx == TIM10)
    {
        rcc = RCC_APB2Periph_TIM10;
    }
    else if (TIMx == TIM11)
    {
        rcc = RCC_APB2Periph_TIM11;
    }
    /* ������ APB1ʱ�� */
    else if (TIMx == TIM2)
    {
        rcc = RCC_APB1Periph_TIM2;
    }
    else if (TIMx == TIM3)
    {
        rcc = RCC_APB1Periph_TIM3;
    }
    else if (TIMx == TIM4)
    {
        rcc = RCC_APB1Periph_TIM4;
    }
    else if (TIMx == TIM5)
    {
        rcc = RCC_APB1Periph_TIM5;
    }
    else if (TIMx == TIM6)
    {
        rcc = RCC_APB1Periph_TIM6;
    }
    else if (TIMx == TIM7)
    {
        rcc = RCC_APB1Periph_TIM7;
    }
    else if (TIMx == TIM12)
    {
        rcc = RCC_APB1Periph_TIM12;
    }
    else if (TIMx == TIM13)
    {
        rcc = RCC_APB1Periph_TIM13;
    }
    else if (TIMx == TIM14)
    {
        rcc = RCC_APB1Periph_TIM14;
    }

    return rcc;
}

/*
*********************************************************************************************************
*	�� �� ��: bsp_SetTIMforInt
*	����˵��: ����TIM��NVIC�����ڼ򵥵Ķ�ʱ�ж�. ������ʱ�жϡ� �жϷ��������Ӧ�ó���ʵ�֡�
*	��    ��: TIMx : ��ʱ��
*			  _ulFreq : ��ʱƵ�� ��Hz���� 0 ��ʾ�رա�
*			  _PreemptionPriority : �ж����ȼ�����
*			  _SubPriority : �����ȼ�
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void bsp_SetTIMforInt(TIM_TypeDef* TIMx, uint32_t _ulFreq, uint8_t _PreemptionPriority, uint8_t _SubPriority)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    uint16_t usPeriod;
    uint16_t usPrescaler;
    uint32_t uiTIMxCLK;

    /* ʹ��TIMʱ�� */
    if ((TIMx == TIM1) || (TIMx == TIM8) || (TIMx == TIM9) || (TIMx == TIM10) || (TIMx == TIM11))
    {
        RCC_APB2PeriphClockCmd(bsp_GetRCCofTIM(TIMx), ENABLE);
    }
    else
    {
        RCC_APB1PeriphClockCmd(bsp_GetRCCofTIM(TIMx), ENABLE);
    }

    if (_ulFreq == 0)
    {
        TIM_Cmd(TIMx, DISABLE);		/* �رն�ʱ��� */
        return;
    }

    /*-----------------------------------------------------------------------
    	system_stm32f4xx.c �ļ��� void SetSysClock(void) ������ʱ�ӵ��������£�

    	HCLK = SYSCLK / 1     (AHB1Periph)
    	PCLK2 = HCLK / 2      (APB2Periph)
    	PCLK1 = HCLK / 4      (APB1Periph)

    	��ΪAPB1 prescaler != 1, ���� APB1�ϵ�TIMxCLK = PCLK1 x 2 = SystemCoreClock / 2;
    	��ΪAPB2 prescaler != 1, ���� APB2�ϵ�TIMxCLK = PCLK2 x 2 = SystemCoreClock;

    	APB1 ��ʱ���� TIM2, TIM3 ,TIM4, TIM5, TIM6, TIM7, TIM12, TIM13,TIM14
    	APB2 ��ʱ���� TIM1, TIM8 ,TIM9, TIM10, TIM11

    ----------------------------------------------------------------------- */
    if ((TIMx == TIM1) || (TIMx == TIM8) || (TIMx == TIM9) || (TIMx == TIM10) || (TIMx == TIM11))
    {
        /* APB2 ��ʱ�� */
        uiTIMxCLK = SystemCoreClock;
    }
    else	/* APB1 ��ʱ�� */
    {
        uiTIMxCLK = SystemCoreClock / 2;
    }

    if (_ulFreq <= 10)
    {
        usPrescaler = 42000 - 1;					/* ��Ƶ�� = 1000 */
        usPeriod =  (uiTIMxCLK / 42000) / _ulFreq  - 1;		/* �Զ���װ��ֵ */
    }

    if (_ulFreq <= 100)
    {
        usPrescaler = 10000 - 1;					/* ��Ƶ�� = 1000 */
        usPeriod =  (uiTIMxCLK / 10000) / _ulFreq  - 1;		/* �Զ���װ��ֵ */
    }
    else if (_ulFreq <= 3000)
    {
        usPrescaler = 100 - 1;					/* ��Ƶ�� = 100 */
        usPeriod =  (uiTIMxCLK / 100) / _ulFreq  - 1;		/* �Զ���װ��ֵ */
    }
    else	/* ����4K��Ƶ�ʣ������Ƶ */
    {
        usPrescaler = 0;					/* ��Ƶ�� = 1 */
        usPeriod = uiTIMxCLK / _ulFreq - 1;	/* �Զ���װ��ֵ */
    }

    /* Time base configuration */
    TIM_TimeBaseStructure.TIM_Period = usPeriod;
    TIM_TimeBaseStructure.TIM_Prescaler = usPrescaler;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0x0000;		/* TIM1 �� TIM8 �������� */

    TIM_TimeBaseInit(TIMx, &TIM_TimeBaseStructure);

    TIM_ARRPreloadConfig(TIMx, ENABLE);

    /* TIM Interrupts enable */
    TIM_ITConfig(TIMx, TIM_IT_Update, ENABLE);

    /* TIMx enable counter */
    TIM_Cmd(TIMx, ENABLE);

    /* ����TIM��ʱ�����ж� (Update) */
    {
        NVIC_InitTypeDef NVIC_InitStructure;	/* �жϽṹ���� misc.h �ж��� */
        uint8_t irq = 0;	/* �жϺ�, ������ stm32f4xx.h */

        if ((TIMx == TIM1) || (TIMx == TIM10))
            irq = TIM1_UP_TIM10_IRQn;
        else if (TIMx == TIM2)
            irq = TIM2_IRQn;
        else if (TIMx == TIM3)
            irq = TIM3_IRQn;
        else if (TIMx == TIM4)
            irq = TIM4_IRQn;
        else if (TIMx == TIM5)
            irq = TIM5_IRQn;
        else if (TIMx == TIM6)
            irq = TIM6_DAC_IRQn;
        else if (TIMx == TIM7)
            irq = TIM7_IRQn;
        else if (TIMx == TIM7)
            irq = TIM7_IRQn;
        else if (TIMx == TIM7)
            irq = TIM7_IRQn;
        else if ((TIMx == TIM8) || (TIMx == TIM13))
            irq = TIM8_UP_TIM13_IRQn;
        else if (TIMx == TIM9)
            irq = TIM1_BRK_TIM9_IRQn;
        else if (TIMx == TIM11)
            irq = TIM1_TRG_COM_TIM11_IRQn;
        else if (TIMx == TIM12)
            irq = TIM8_BRK_TIM12_IRQn;
        else if (TIMx == TIM12)
            irq = TIM8_TRG_COM_TIM14_IRQn;

        NVIC_InitStructure.NVIC_IRQChannel = irq;
        NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = _PreemptionPriority;
        NVIC_InitStructure.NVIC_IRQChannelSubPriority = _SubPriority;
        NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
        NVIC_Init(&NVIC_InitStructure);
    }
}


/*******************************************************************************
* Function Name  : delay_init
* Description    : delay_init
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void delay_init(void)
{    
    __set_PRIMASK(1);
    bsp_SetTIMforInt(US_delay_TIM, 1400000, 10, 1);
    TIM_Cmd(US_delay_TIM, DISABLE);
    TIM_ITConfig(US_delay_TIM, TIM_IT_Update, DISABLE);	
	  __set_PRIMASK(0);
}


/*******************************************************************************
* Function Name  : delay_us(u32 nus)
* Description    : delay_us
* Input          : u32 nus
* Output         : None
* Return         : None
*******************************************************************************/
void delay_us(u32 nus)
{
    u32 cnt;
    cnt = nus;
    TIM_Cmd(US_delay_TIM, ENABLE);

    while(cnt--)
    {
        while(TIM_GetFlagStatus(US_delay_TIM, TIM_FLAG_Update) == RESET);

        TIM_ClearFlag(US_delay_TIM, TIM_FLAG_Update);
    }

    TIM_Cmd(US_delay_TIM, DISABLE);
}
/*******************************************************************************
* Function Name  : delay_ms(u16 nms)
* Description    : delay_us
* Input          : u32 nus
* Output         : None
* Return         : None
*******************************************************************************/
void delay_ms(u16 repeat)
{	 	 				
	while(repeat)
  {
		repeat--;
		delay_us(1500);
	}
} 
/*******************************************************************************
* Function Name  : TIM7_IRQHandler(void)
* Description    : TIM7_IRQHandler
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void TIM7_IRQHandler( void )
{
    if(TIM_GetITStatus(US_delay_TIM, TIM_IT_Update) != RESET)
    {
        TIM_ClearITPendingBit(US_delay_TIM, TIM_IT_Update);
    }
}

/******************************************************************************
* Function Name  : USART_Scanf(void) 
* Description    : rev the uart data
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
uint8_t USART_Scanf(uint32_t value)
{
	uint32_t index = 0;
	uint32_t tmp[2] = {0, 0};

	while (index < 2)
	{
		// RXNE = 1 
		while (USART_GetFlagStatus(USART1, USART_FLAG_RXNE) == RESET)
		{}
		tmp[index++] = (USART_ReceiveData(USART1));
		if ((tmp[index - 1] < 0x30) || (tmp[index - 1] > 0x39))
		{
			index--;
		}
	}
	index = (tmp[1] - 0x30) + ((tmp[0] - 0x30) * 10);
	/* Checks */
	if (index > value)
	{
		return 0xFF;
	}
	
	return index;
}

/*******************************************************************************
* Function Name  : ModuleCheck(void)
* Description    : check the module
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void ModuleCheck(void)
{
		if((VS_CK_PIN1 == SET)&&(VS_CK_PIN2 == RESET)&&(VS_CK_PIN3 == RESET)&&(VS_CK_PIN4 == RESET))   //001
		{			
			//MODULE_LED1_ON;MODULE_LED2_OFF;MODULE_LED3_OFF;	
			;			
		}
		else if((VS_CK_PIN1 == SET)&&(VS_CK_PIN2 == SET)&&(VS_CK_PIN3 == SET)&&(VS_CK_PIN4 == SET))   //1111
		{
			FlagVsModel = 0x0f;
		} 		
		else;
}

uint16_t ucStatus = 0;
/*******************************************************************************
* Function Name  : vSystemHardwareDriverInit(void)
* Description    : init the driver
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void vSystemHardwareDriverInit(void)
{	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);	
	delay_init();   
	BspIoConfig();  
	ModuleCheck();	
	syl_can_Init();
}
  
/*******************************************************************************
* Function Name  : CanProPre
* Description    : CAN
* Input          : None
* Output         : None
* Return         : None
********************************************************************************/
void vSystemCanProPre(void)
{
		if(PriorityToken)
		{
				switch(g_tCanRxMsg.Data[1])
				{
						case 0x04:
								ucQueueMsgFunction = g_tCanRxMsg.Data[2] << 8 | g_tCanRxMsg.Data[3];

								switch(ucQueueMsgFunction)
								{
										case 0x00:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[0] == ucQueueMsgValue);
												else usSRegInBuf[0] =  ucQueueMsgValue;
												break;

										case 0x01:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[1] == ucQueueMsgValue);
												else usSRegInBuf[1] =  ucQueueMsgValue;
												break;

										case 0x02:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[2] == ucQueueMsgValue);
												else usSRegInBuf[2] =  ucQueueMsgValue;
												break;

										case 0x03:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[3] == ucQueueMsgValue);
												else usSRegInBuf[3] =  ucQueueMsgValue;
												break;

										case 0x04:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[4] == ucQueueMsgValue);
												else usSRegInBuf[4] =  ucQueueMsgValue;
												break;

										case 0x05:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[5] == ucQueueMsgValue);
												else usSRegInBuf[5] =  ucQueueMsgValue;
												break;

										case 0x06:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[6] == ucQueueMsgValue);
												else usSRegInBuf[6] =  ucQueueMsgValue;
												break;

										case 0x07:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[7] == ucQueueMsgValue);
												else usSRegInBuf[7] =  ucQueueMsgValue;
												break;

										case 0x08:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[8] == ucQueueMsgValue);
												else usSRegInBuf[8] =  ucQueueMsgValue;
												break;

										case 0x09:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[9] == ucQueueMsgValue);
												else usSRegInBuf[9] =  ucQueueMsgValue;
												break;

										case 0x0A:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[10] == ucQueueMsgValue);
												else usSRegInBuf[10] =  ucQueueMsgValue;
												break;

										case 0x0B:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[12] == ucQueueMsgValue);
												else usSRegInBuf[12] =  ucQueueMsgValue;
												break;

										case 0x0C:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[13] == ucQueueMsgValue);
												else usSRegInBuf[13] =  ucQueueMsgValue;
												break;

										case 0x0D:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[14] == ucQueueMsgValue);
												else usSRegInBuf[14] =  ucQueueMsgValue;
												break;

										case 0x0E:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[15] == ucQueueMsgValue);
												else usSRegInBuf[15] =  ucQueueMsgValue;
												break;

										case 0x0F:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[16] == ucQueueMsgValue);
												else usSRegInBuf[16] =  ucQueueMsgValue;
												break;

										case 0x10:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[17] == ucQueueMsgValue);
												else usSRegInBuf[17] =  ucQueueMsgValue;
												break;

										case 0x11:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[18] == ucQueueMsgValue);
												else usSRegInBuf[18] =  ucQueueMsgValue;
												break;

										case 0x12:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[19] == ucQueueMsgValue);
												else usSRegInBuf[19] =  ucQueueMsgValue;
												break;

										case 0x13:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[20] == ucQueueMsgValue);
												else usSRegInBuf[20] =  ucQueueMsgValue;
												break;

										case 0x14:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[21] == ucQueueMsgValue);
												else usSRegInBuf[21] =  ucQueueMsgValue;
												break;

										case 0x15:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[22] == ucQueueMsgValue);
												else usSRegInBuf[22] =  ucQueueMsgValue;
												break;

										case 0x16:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[23] == ucQueueMsgValue);
												else usSRegInBuf[23] =  ucQueueMsgValue;
												break;

										case 0x17:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[24] == ucQueueMsgValue);
												else usSRegInBuf[24] =  ucQueueMsgValue;
												break;

										case 0x18:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[25] == ucQueueMsgValue);
												else usSRegInBuf[25] =  ucQueueMsgValue;
												break;

										
										case 0x19:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[26] == ucQueueMsgValue);
												else usSRegInBuf[26] =  ucQueueMsgValue;
												break;

										case 0x1A:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[27] == ucQueueMsgValue);
												else usSRegInBuf[27] =  ucQueueMsgValue;
												break;

										case 0x1B:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[28] == ucQueueMsgValue);
												else usSRegInBuf[28] =  ucQueueMsgValue;
												break;

										case 0x1C:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[29] == ucQueueMsgValue);
												else usSRegInBuf[29] =  ucQueueMsgValue;
												break;

										case 0x1D:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[30] == ucQueueMsgValue);
												else usSRegInBuf[30] =  ucQueueMsgValue;
												break;

										case 0x1E:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[31] == ucQueueMsgValue);
												else usSRegInBuf[31] =  ucQueueMsgValue;
												break;

										case 0x1F:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[32] == ucQueueMsgValue);
												else usSRegInBuf[32] =  ucQueueMsgValue;
												break;

										case 0x20:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[33] == ucQueueMsgValue);
												else usSRegInBuf[33] =  ucQueueMsgValue;
												break;

										case 0x21:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[34] == ucQueueMsgValue);
												else usSRegInBuf[34] =  ucQueueMsgValue;
												break;

										case 0x22:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[35] == ucQueueMsgValue);
												else usSRegInBuf[35] =  ucQueueMsgValue;
												break;

										case 0x23:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[36] == ucQueueMsgValue);
												else usSRegInBuf[36] =  ucQueueMsgValue;
												break;

										case 0x24:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[37] == ucQueueMsgValue);
												else usSRegInBuf[37] =  ucQueueMsgValue;
												break;

										case 0x25:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[38] == ucQueueMsgValue);
												else usSRegInBuf[38] =  ucQueueMsgValue;
												break;

										case 0x26:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[39] == ucQueueMsgValue);
												else usSRegInBuf[39] =  ucQueueMsgValue;
												break;

										case 0x27:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												if(usSRegInBuf[40] == ucQueueMsgValue);
												else usSRegInBuf[40] =  ucQueueMsgValue;
												break;
										
										case 0x28:
												ucQueueMsgValue = g_tCanRxMsg.Data[5] << 8 | g_tCanRxMsg.Data[6];
												break;													
										default:
												break;
								}
								break;
						case 0x03:
								ucQueueMsgFunction = g_tCanRxMsg.Data[2] << 8 | g_tCanRxMsg.Data[3];
								switch(ucQueueMsgFunction)
								{
										case 0x00:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];

												if(usRegHoldingBuf[501] == ucQueueMsgValue);
												else usRegHoldingBuf[501] =  ucQueueMsgValue;

												break;

										case 0x01:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[502] == ucQueueMsgValue);
												else usRegHoldingBuf[502] =  ucQueueMsgValue;
												break;

										case 0x02:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[503] == ucQueueMsgValue);
												else usRegHoldingBuf[503] =  ucQueueMsgValue;
												break;

										case 0x03:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												ucQueueMsgValue = ucQueueMsgValue*10;
												if(usRegHoldingBuf[504] == ucQueueMsgValue);
												else usRegHoldingBuf[504] =  ucQueueMsgValue;
												break;

										case 0x04:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												ucQueueMsgValue = ucQueueMsgValue*10;
												if(usRegHoldingBuf[505] == ucQueueMsgValue);
												else usRegHoldingBuf[505] =  ucQueueMsgValue;
												break;

										case 0x05:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												ucQueueMsgValue = ucQueueMsgValue*10;
												if(usRegHoldingBuf[506] == ucQueueMsgValue);
												else usRegHoldingBuf[506] =  ucQueueMsgValue;
												break;

										case 0x06:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												ucQueueMsgValue = ucQueueMsgValue*10;
												if(usRegHoldingBuf[507] == ucQueueMsgValue);
												else usRegHoldingBuf[507] =  ucQueueMsgValue;
												break;

										case 0x07:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												ucQueueMsgValue = ucQueueMsgValue*10;
												if(usRegHoldingBuf[508] == ucQueueMsgValue);
												else usRegHoldingBuf[508] =  ucQueueMsgValue;
												break;

										case 0x08:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[509] == ucQueueMsgValue);
												else usRegHoldingBuf[509] =  ucQueueMsgValue;
												break;

										case 0x09:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[510] == ucQueueMsgValue);
												else usRegHoldingBuf[510] =  ucQueueMsgValue;
												break;

										case 0x0A:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[511] == ucQueueMsgValue);
												else usRegHoldingBuf[511] =  ucQueueMsgValue;
												break;

										case 0x0B:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[512] == ucQueueMsgValue);
												else usRegHoldingBuf[512] =  ucQueueMsgValue;
												break;

										case 0x0C:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[513] == ucQueueMsgValue);
												else usRegHoldingBuf[513] =  ucQueueMsgValue;
												break;

										case 0x0D:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[514] == ucQueueMsgValue);
												else usRegHoldingBuf[514] =  ucQueueMsgValue;
												break;

										case 0x0E:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[515] == ucQueueMsgValue);
												else usRegHoldingBuf[515] =  ucQueueMsgValue;
												break;

										case 0x0F:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];

												if(usRegHoldingBuf[516] == ucQueueMsgValue);
												else usRegHoldingBuf[516] =  ucQueueMsgValue;

												break;
										
										case 0x10:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[517] == ucQueueMsgValue);
												else usRegHoldingBuf[517] =  ucQueueMsgValue;
												break;
										
										case 0x11:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[518] == ucQueueMsgValue);
												else usRegHoldingBuf[518] =  ucQueueMsgValue;
												break;

										case 0x12:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[519] == ucQueueMsgValue);
												else usRegHoldingBuf[519] =  ucQueueMsgValue;
												break;

										case 0x13:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[520] == ucQueueMsgValue);
												else usRegHoldingBuf[520] =  ucQueueMsgValue;
												break;

										case 0x14:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[521] == ucQueueMsgValue);
												else usRegHoldingBuf[521] =  ucQueueMsgValue;
												break;

										case 0x15:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[522] == ucQueueMsgValue);
												else usRegHoldingBuf[522] =  ucQueueMsgValue;
												break;

										case 0x16:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[6];
												if(usRegHoldingBuf[523] == ucQueueMsgValue);
												else usRegHoldingBuf[523] =  ucQueueMsgValue;
												break;

										case 0x17:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[524] == ucQueueMsgValue);
												else usRegHoldingBuf[524] =  ucQueueMsgValue;
												break;

										case 0x18:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[525] == ucQueueMsgValue);
												else usRegHoldingBuf[525] =  ucQueueMsgValue;
												break;

										case 0x19:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[526] == ucQueueMsgValue);
												else usRegHoldingBuf[526] =  ucQueueMsgValue;
												break;

										case 0x1A:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[527] == ucQueueMsgValue);
												else usRegHoldingBuf[527] =  ucQueueMsgValue;
												break;

										case 0x1B:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[528] == ucQueueMsgValue);
												else usRegHoldingBuf[528] =  ucQueueMsgValue;
												break;

										case 0x1C:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[529] == ucQueueMsgValue);
												else usRegHoldingBuf[529] =  ucQueueMsgValue;
												break;

										case 0x1D:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[530] == ucQueueMsgValue);
												else usRegHoldingBuf[530] =  ucQueueMsgValue;
												break;

										case 0x1E:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[531] == ucQueueMsgValue);
												else usRegHoldingBuf[531] =  ucQueueMsgValue;
												break;	

										case 0x1F:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[532] == ucQueueMsgValue);
												else usRegHoldingBuf[532] =  ucQueueMsgValue;
												break;
										
										case 0x20:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[533] == ucQueueMsgValue);
												else usRegHoldingBuf[533] =  ucQueueMsgValue;
												break;
										
										case 0x21:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[534] == ucQueueMsgValue);
												else usRegHoldingBuf[534] =  ucQueueMsgValue;
												break;

										case 0x22:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[535] == ucQueueMsgValue);
												else usRegHoldingBuf[535] =  ucQueueMsgValue;
												break;

										case 0x23:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[536] == ucQueueMsgValue);
												else usRegHoldingBuf[536] =  ucQueueMsgValue;
												break;

										case 0x24:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[537] == ucQueueMsgValue);
												else usRegHoldingBuf[537] =  ucQueueMsgValue;
												break;

										case 0x25:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[538] == ucQueueMsgValue);
												else usRegHoldingBuf[538] =  ucQueueMsgValue;
												break;

										case 0x26:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[539] == ucQueueMsgValue);
												else usRegHoldingBuf[539] =  ucQueueMsgValue;
												break;

										case 0x27:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[540] == ucQueueMsgValue);
												else usRegHoldingBuf[540] =  ucQueueMsgValue;
												break;

										case 0x28:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[541] == ucQueueMsgValue);
												else usRegHoldingBuf[541] =  ucQueueMsgValue;
												break;

										case 0x29:
												ucQueueMsgValue = g_tCanRxMsg.Data[4] << 8 | g_tCanRxMsg.Data[5];
												if(usRegHoldingBuf[542] == ucQueueMsgValue);
												else usRegHoldingBuf[542] =  ucQueueMsgValue;
												break;					
										default:
												break;
								}

								break;

						default:
								break;
				}
				PriorityToken = 0;
		}
}
